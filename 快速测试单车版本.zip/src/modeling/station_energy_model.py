# src/modeling/station_energy_model.py
from pyomo.environ import *


def create_station_energy_model(station_data, config):
    """
    为单个换电站创建能源调度优化模型(LP)。
    此版本经过修正，增加了弃光(curtailment)处理，以确保在任何情况下模型都可行。
    """
    model = ConcreteModel(name="StationEnergyModel")

    # --- Sets ---
    model.T = Set(initialize=station_data['time_steps'])

    # --- Parameters ---
    model.pv_gen = Param(model.T, initialize=station_data['pv_generation'])
    model.ev_demand = Param(model.T, initialize=station_data['ev_demand'])
    model.hdt_demand = Param(model.T, initialize=station_data['hdt_demand'])
    model.prices = Param(model.T, initialize=station_data['electricity_prices'])

    # --- Variables ---
    model.p_grid = Var(model.T, within=NonNegativeReals, bounds=(0, config.STATION_MAX_GRID_POWER_KW))
    model.p_bess_ch = Var(model.T, within=NonNegativeReals, bounds=(0, config.STATION_BESS_MAX_POWER_KW))
    model.p_bess_dis = Var(model.T, within=NonNegativeReals, bounds=(0, config.STATION_BESS_MAX_POWER_KW))
    model.e_bess = Var(model.T, within=NonNegativeReals, bounds=(0, config.STATION_BESS_CAPACITY_KWH))

    # --- [核心修正] 增加处理“能量过剩”和“能量不足”的松弛变量 ---
    # 1. 弃光功率 (处理能量过剩)
    model.p_pv_curtailed = Var(model.T, within=NonNegativeReals)
    # 2. 未满足的负荷 (处理能量不足)
    model.unmet_ev_demand = Var(model.T, within=NonNegativeReals)
    model.unmet_hdt_demand = Var(model.T, within=NonNegativeReals)

    # --- Objective Function ---
    def objective_rule(m):
        # 成本项：从电网购电的成本
        cost = sum(m.p_grid[t] * m.prices[t] * config.TIME_STEP_HOURS for t in m.T)

        # 惩罚项：对未能满足的需求进行惩罚
        penalty_unmet_demand = sum(
            (m.unmet_ev_demand[t] + m.unmet_hdt_demand[t]) * config.EV_UNSERVED_PENALTY_PER_KWH for t in m.T)

        # 惩罚项(可选，很小): 对弃光行为进行轻微惩罚，鼓励优先使用光伏
        penalty_curtailment = sum(m.p_pv_curtailed[t] * 0.01 for t in m.T)

        return cost + penalty_unmet_demand + penalty_curtailment

    model.objective = Objective(rule=objective_rule, sense=minimize)

    # --- Constraints ---
    model.constrains = ConstraintList()

    # [核心修正] 修正能量平衡与弃光约束
    for t in model.T:
        # 实际使用的光伏功率 = 总发电 - 弃光功率
        used_pv = model.pv_gen[t] - model.p_pv_curtailed[t]

        # 供给侧 (In-flow)
        in_flow = model.p_grid[t] + used_pv + model.p_bess_dis[t]

        # 需求侧 (Out-flow)，现在包含了未满足需求的部分
        out_flow = model.p_bess_ch[t] + (model.ev_demand[t] - model.unmet_ev_demand[t]) + (
                    model.hdt_demand[t] - model.unmet_hdt_demand[t])

        # 能量平衡方程
        model.constrains.add(in_flow == out_flow)

        # 弃光功率不能超过总发电量
        model.constrains.add(model.p_pv_curtailed[t] <= model.pv_gen[t])

    # 储能SOC动态约束 (此部分逻辑不变)
    for t in model.T:
        if t == model.T.first():
            # 假设初始SOC为50%
            prev_soc = config.STATION_BESS_CAPACITY_KWH * 0.5
        else:
            prev_soc = model.e_bess[t - 1]

        charge_energy = model.p_bess_ch[t] * config.STATION_BESS_EFFICIENCY * config.TIME_STEP_HOURS
        discharge_energy = (model.p_bess_dis[t] / config.STATION_BESS_EFFICIENCY) * config.TIME_STEP_HOURS
        model.constrains.add(model.e_bess[t] == prev_soc + charge_energy - discharge_energy)

    return model