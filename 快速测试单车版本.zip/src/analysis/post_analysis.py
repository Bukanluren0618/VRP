# src/analysis/post_analysis.py

import os
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import networkx as nx
import pandas as pd
from pyomo.environ import value
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def safe_value(var_or_data):
    if hasattr(var_or_data, 'is_variable_type') and var_or_data.is_variable_type():
        return value(var_or_data, exception=False) if var_or_data.value is not None else 0
    return var_or_data

def plot_road_network_with_routes(final_routes, data, filename="fleet_routing_plan.png"):
    print("正在绘制HDT车队最终路径规划图...")
    G = data['traffic_graph']
    pos = nx.get_node_attributes(G, 'pos')
    plt.figure(figsize=(24, 20))
    nx.draw_networkx_edges(G, pos, edge_color='gray', alpha=0.2)
    node_types = {info['node_id']: info['type'] for info in data['locations'].values()}
    depots = [n for n, t in node_types.items() if t == 'Depot']
    customers = [n for n, t in node_types.items() if t == 'Customer']
    stations = [n for n, t in node_types.items() if t == 'SwapStation']
    nx.draw_networkx_nodes(G, pos, nodelist=depots, node_color='red', node_size=300, node_shape='s', label='仓库')
    nx.draw_networkx_nodes(G, pos, nodelist=customers, node_color='skyblue', node_size=150, label='客户')
    nx.draw_networkx_nodes(G, pos, nodelist=stations, node_color='lightgreen', node_size=250, node_shape='p', label='换电站')
    nx.draw_networkx_labels(G, pos, font_size=7)
    vehicle_colors = plt.cm.get_cmap('gist_rainbow', len(final_routes))
    for k_idx, (k, route_info) in enumerate(final_routes.items()):
        route_nodes_names = route_info['route']
        if not route_nodes_names or len(route_nodes_names) <= 2: continue
        route_node_ids = [data['locations'][name]['node_id'] for name in route_nodes_names]
        color = vehicle_colors(k_idx)
        for i in range(len(route_node_ids) - 1):
            u, v = route_node_ids[i], route_node_ids[i + 1]
            path_segment = data['path_matrix'].loc[route_nodes_names[i], route_nodes_names[i + 1]]
            if path_segment and len(path_segment) > 1:
                path_edges = list(zip(path_segment[:-1], path_segment[1:]))
                nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color=color, width=2.0, style='dashed', alpha=0.9)
    plt.title("HDT车队最终路径规划方案", fontsize=24)
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    plt.legend(by_label.values(), by_label.keys(), loc='upper right', fontsize=10)
    plt.tight_layout()
    save_path = os.path.join(os.getcwd(), "results", filename) # Use a robust path
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"车队路径图已保存到: {save_path}")

def plot_individual_truck_analysis(vehicle_id, route_info, data, config):
    filename_prefix=f"truck_analysis_{vehicle_id}"
    print(f"正在为车辆 {vehicle_id} 生成详细分析图...")
    model = route_info['model']
    if not model:
        print(f"车辆 {vehicle_id} 没有可供分析的模型数据。")
        return

    # --- 图1: 单车路径图 ---
    G = data['traffic_graph']
    pos = nx.get_node_attributes(G, 'pos')
    plt.figure(figsize=(12, 10))
    nx.draw_networkx_edges(G, pos, edge_color='gray', alpha=0.2)
    node_types = {info['node_id']: info['type'] for info in data['locations'].values()}
    depots = [n for n, t in node_types.items() if t == 'Depot']
    customers = [n for n, t in node_types.items() if t == 'Customer']
    stations = [n for n, t in node_types.items() if t == 'SwapStation']
    nx.draw_networkx_nodes(G, pos, nodelist=depots, node_color='red', node_size=300, node_shape='s', label='仓库')
    nx.draw_networkx_nodes(G, pos, nodelist=customers, node_color='skyblue', node_size=150, label='客户')
    nx.draw_networkx_nodes(G, pos, nodelist=stations, node_color='lightgreen', node_size=250, node_shape='p', label='换电站')
    route_node_names = route_info['route']
    route_node_ids = [data['locations'][name]['node_id'] for name in route_node_names]
    nx.draw_networkx_nodes(G, pos, nodelist=route_node_ids, node_color='magenta', node_size=100)
    for i in range(len(route_node_ids) - 1):
        path_segment = data['path_matrix'].loc[route_node_names[i], route_node_names[i + 1]]
        if path_segment and len(path_segment) > 1:
            path_edges = list(zip(path_segment[:-1], path_segment[1:]))
            nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='magenta', width=2.5, style='solid')
    plt.title(f"车辆 {vehicle_id} 的行驶路径", fontsize=16)
    plt.legend()
    save_path = os.path.join(os.getcwd(), "results", f"{filename_prefix}_route.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()

    # --- 图2: 电量与载重变化图 ---
    timeline, soc_line, weight_line = [], [], []
    for loc_name in route_node_names:
        timeline.append(safe_value(model.arrival_time[loc_name, vehicle_id]))
        soc_line.append(safe_value(model.soc_arrival[loc_name, vehicle_id]))
        weight_line.append(safe_value(model.weight_on_arrival[loc_name, vehicle_id]))
    fig, ax1 = plt.subplots(figsize=(15, 7))
    color = 'tab:blue'
    ax1.set_xlabel('时间 (小时)')
    ax1.set_ylabel('电池电量 (kWh)', color=color)
    ax1.plot(timeline, soc_line, color=color, marker='o', label='电池电量')
    ax1.tick_params(axis='y', labelcolor=color)
    ax1.axhline(y=config.HDT_MIN_SOC_KWH, color='red', linestyle='--', label=f'安全电量阈值 ({config.HDT_MIN_SOC_KWH} kWh)')
    ax1.grid(True)
    ax2 = ax1.twinx()
    color = 'tab:orange'
    ax2.set_ylabel('车辆载重 (吨)', color=color)
    ax2.step(timeline, weight_line, where='post', color=color, label='车辆载重')
    ax2.tick_params(axis='y', labelcolor=color)
    plt.title(f'车辆 {vehicle_id} 的电量与载重变化分析', fontsize=16)
    fig.tight_layout()
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax2.legend(lines + lines2, labels + labels2, loc='upper center')
    save_path = os.path.join(os.getcwd(), "results", f"{filename_prefix}_metrics.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"车辆 {vehicle_id} 的详细分析图已保存。")

def plot_station_energy_flows(station_id, model, station_data, config, filename_prefix="station_analysis"):
    print(f"正在为换电站 {station_id} 生成能源调度分析图...")
    time_steps = station_data['time_steps']
    hours = [t * config.TIME_STEP_HOURS for t in time_steps]
    p_grid = [safe_value(model.p_grid[t]) for t in time_steps]
    p_bess_ch = [safe_value(model.p_bess_ch[t]) for t in time_steps]
    p_bess_dis = [safe_value(model.p_bess_dis[t]) for t in time_steps]
    e_bess_kwh = [safe_value(model.e_bess[t]) for t in time_steps]
    pv_gen = [safe_value(model.pv_gen[t]) for t in time_steps]
    ev_demand = [safe_value(model.ev_demand[t]) for t in time_steps]
    hdt_demand = [safe_value(model.hdt_demand[t]) for t in time_steps]
    fig, ax1 = plt.subplots(figsize=(18, 9))
    ax1.fill_between(hours, 0, p_grid, alpha=0.7, label='从电网购电 (kW)', step='post')
    ax1.fill_between(hours, p_grid, [x+y for x,y in zip(p_grid, pv_gen)], alpha=0.7, label='光伏发电 (kW)', step='post')
    ax1.fill_between(hours, [x+y for x,y in zip(p_grid, pv_gen)], [x+y+z for x,y,z in zip(p_grid, pv_gen, p_bess_dis)], alpha=0.7, label='储能放电 (kW)', step='post')
    total_demand = [x+y for x,y in zip(ev_demand, hdt_demand)]
    ax1.plot(hours, total_demand, 'r--', label='总负荷 (EV+HDT) (kW)')
    ax1.plot(hours, p_bess_ch, 'g-.', label='储能充电 (kW)')
    ax1.set_xlabel("时间 (小时)")
    ax1.set_ylabel("功率 (kW)")
    ax1.set_title(f"换电站 {station_id} (连接至电网节点 {station_data['bus_id']}) - 能源调度计划", fontsize=16)
    ax1.grid(True)
    ax1.legend(loc='upper left')
    ax2 = ax1.twinx()
    ax2.set_ylabel("储能SOC (kWh)", color='purple')
    ax2.plot(hours, e_bess_kwh, color='purple', linestyle=':', linewidth=3, label='储能SOC (kWh)')
    ax2.tick_params(axis='y', labelcolor='purple')
    ax2.legend(loc='upper right')
    fig.tight_layout()
    save_path = os.path.join(os.getcwd(), "results", f"{filename_prefix}_{station_id}.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"换电站 {station_id} 的能源调度图已保存。")

def plot_fleet_summary(fleet_summary_data, cost_summary, config):
    print("正在生成车队运营总结图...")
    if not fleet_summary_data:
        print("无车队数据可供分析。")
        return
    df = pd.DataFrame.from_dict(fleet_summary_data, orient='index')
    fig, axes = plt.subplots(2, 2, figsize=(20, 15))
    fig.suptitle('车队运营性能总结', fontsize=24)
    df['duration'].sort_values().plot(kind='bar', ax=axes[0, 0], color='skyblue')
    axes[0, 0].set_title('各车辆总行驶时长')
    axes[0, 0].set_ylabel('时长 (小时)')
    axes[0, 0].tick_params(axis='x', rotation=45)
    df['distance'].sort_values().plot(kind='bar', ax=axes[0, 1], color='salmon')
    axes[0, 1].set_title('各车辆总行驶距离')
    axes[0, 1].set_ylabel('距离 (公里)')
    axes[0, 1].tick_params(axis='x', rotation=45)
    df['tasks'].sort_values().plot(kind='bar', ax=axes[1, 0], color='lightgreen')
    axes[1, 0].set_title('各车辆服务任务数')
    axes[1, 0].set_ylabel('任务数')
    axes[1, 0].tick_params(axis='x', rotation=45)
    cost_series = pd.Series(cost_summary)
    if not cost_series.empty and cost_series.sum() > 0:
        axes[1, 1].pie(cost_series, labels=cost_series.index, autopct='%1.1f%%', startangle=90, colors=['gold', 'lightcoral', 'lightskyblue'])
        axes[1, 1].set_title('总运输成本构成')
    else:
        axes[1,1].text(0.5, 0.5, '无成本数据', horizontalalignment='center', verticalalignment='center')
    axes[1,1].axis('equal')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    save_path = os.path.join(os.getcwd(), "results", "summary_fleet_performance.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"车队运营总结图已保存到: {save_path}")

def plot_task_delays(delay_data):
    print("正在生成任务准时性分析图...")
    if not delay_data:
        print("无任务延误数据可供分析。")
        return
    df = pd.DataFrame(delay_data)
    plt.figure(figsize=(12, 8))
    ontime = df[df['delay'] <= 0.01]
    late = df[df['delay'] > 0.01]
    plt.scatter(ontime['due_time'], ontime['arrival_time'], color='green', alpha=0.7, label=f'准时/早达 ({len(ontime)})')
    plt.scatter(late['due_time'], late['arrival_time'], color='red', alpha=0.7, label=f'迟到 ({len(late)})')
    max_time = max(df['due_time'].max(), df['arrival_time'].max()) if not df.empty else 24
    plt.plot([0, max_time], [0, max_time], 'k--', label='准时线 (到达时间 = 截止时间)')
    plt.title('任务送达准时性分析', fontsize=18)
    plt.xlabel('任务要求截止时间 (小时)')
    plt.ylabel('车辆实际到达时间 (小时)')
    plt.legend()
    plt.grid(True)
    plt.axis('equal')
    plt.tight_layout()
    save_path = os.path.join(os.getcwd(), "results", "summary_task_delays.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"任务准时性图已保存到: {save_path}")

def plot_gantt_chart(vehicle_id, route_info, data, config):
    print(f"正在为车辆 {vehicle_id} 生成甘特图...")
    model = route_info['model']
    route = route_info['route']
    if len(route) <= 2: return
    fig, ax = plt.subplots(figsize=(18, 5))
    event_y = 0.5
    for i in range(len(route) - 1):
        loc_i, loc_j = route[i], route[i+1]
        start_time = safe_value(model.departure_time[loc_i, vehicle_id])
        end_time = safe_value(model.arrival_time[loc_j, vehicle_id])
        duration = end_time - start_time
        if duration > 0.01:
            ax.barh(event_y, duration, left=start_time, height=0.5, color='royalblue', edgecolor='black')
            ax.text(start_time + duration/2, event_y, f'行驶\n{loc_i} -> {loc_j}', ha='center', va='center', color='white', fontsize=8)
        service_start = end_time
        service_end = safe_value(model.departure_time[loc_j, vehicle_id])
        service_duration = service_end - service_start
        if service_duration > 0.01:
            loc_type = data['locations'][loc_j]['type']
            color = 'orange' if loc_type == 'Customer' else 'lightgreen' if loc_type == 'SwapStation' else 'gray'
            label = '服务客户' if loc_type == 'Customer' else '换电' if loc_type == 'SwapStation' else '停留'
            ax.barh(event_y, service_duration, left=service_start, height=0.5, color=color, edgecolor='black')
            ax.text(service_start + service_duration/2, event_y, f'{label}\n@{loc_j}', ha='center', va='center', color='black', fontsize=8)
    ax.set_yticks([])
    ax.set_xlabel('时间 (小时)')
    ax.set_title(f'车辆 {vehicle_id} 调度甘特图', fontsize=16)
    ax.grid(axis='x')
    plt.xlim(0, config.TIME_HORIZON_HOURS)
    save_path = os.path.join(os.getcwd(), "results", f"gantt_chart_{vehicle_id}.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()

def plot_station_summary(station_summary_data, config):
    print("正在生成换电站网络运营总结图...")
    if not station_summary_data:
        print("无换电站数据可供分析。")
        return
    df = pd.DataFrame.from_dict(station_summary_data, orient='index')
    fig, axes = plt.subplots(1, 2, figsize=(18, 8))
    fig.suptitle('换电站网络能源运营总结', fontsize=20)
    if 'cost' in df.columns and not df['cost'].empty:
        df['cost'].sort_values().plot(kind='bar', ax=axes[0], color='purple')
    axes[0].set_title('各换电站日能源成本')
    axes[0].set_ylabel('成本 (元)')
    axes[0].tick_params(axis='x', rotation=45)
    if not df.empty:
        energy_totals = df[['total_grid_kwh', 'total_pv_kwh', 'total_ev_kwh', 'total_hdt_kwh']].sum()
        supply_labels = ['电网购电', '光伏发电']
        supply_values = [energy_totals['total_grid_kwh'], energy_totals['total_pv_kwh']]
        supply_patch = [mpatches.Patch(color=c, label=f"{l} ({v:.1f} kWh)") for l,v,c in zip(supply_labels, supply_values, ['skyblue', 'gold'])]
        demand_labels = ['外部EV充电', 'HDT换电']
        demand_values = [energy_totals['total_ev_kwh'], energy_totals['total_hdt_kwh']]
        demand_patch = [mpatches.Patch(color=c, label=f"{l} ({v:.1f} kWh)") for l,v,c in zip(demand_labels, demand_values, ['salmon', 'lightgreen'])]
        axes[1].legend(handles=supply_patch + demand_patch, loc='center', title='能源流向 (kWh)', fontsize=12)
    axes[1].axis('off')
    axes[1].set_title('全网络总能源结构')
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    save_path = os.path.join(os.getcwd(), "results", "summary_station_network.png")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path)
    plt.close()
    print(f"换电站网络运营总结图已保存到: {save_path}")