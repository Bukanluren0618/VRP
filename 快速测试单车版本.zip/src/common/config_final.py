# HDT_Swapping_Optimization/src/common/config_final.py
import os

# --- 路径定义 ---
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RESULTS_DIR = os.path.join(PROJECT_ROOT, "results")
DATA_DIR = os.path.join(PROJECT_ROOT, "data", "raw")
os.makedirs(RESULTS_DIR, exist_ok=True)

# --- 文件名定义 ---
CHARGE_LOAD_FILENAME = "充电负荷报表-海宜路1、2号5月.csv"
BATTERY_SOC_FILENAME = "电池SOC数据.csv"

# --- [最终验证场景] ---
CITY_NODE_COUNT = 200
CITY_GRAPH_RADIUS = 0.25
NUM_DEPOTS = 5
NUM_TRUCKS = 30
NUM_STATIONS = 15
NUM_CUSTOMERS = 100
MIN_TASKS_PER_TRUCK = 3
MAX_TASKS_PER_TRUCK = 15
CITY_SCALE_KM = 40.0

# --- 时间离散化 ---
TIME_HORIZON_HOURS = 24
TIME_STEP_MINUTES = 30
TOTAL_TIME_STEPS = int(TIME_HORIZON_HOURS * 60 / TIME_STEP_MINUTES)
TIME_STEP_HOURS = TIME_STEP_MINUTES / 60.0

# --- 经济与惩罚参数 ---
MANPOWER_COST_PER_HOUR = 150.0
DELAY_PENALTY_PER_HOUR = 800.0
FIXED_SWAP_COST = 50.0
EV_UNSERVED_PENALTY_PER_KWH = 10.0
GRID_PEAK_PRICE_PENALTY = 50.0
UNASSIGNED_TASK_PENALTY = 2000000.0
AVG_TASKS_PER_TRUCK = (MIN_TASKS_PER_TRUCK + MAX_TASKS_PER_TRUCK) / 2
MAX_WORKING_HOURS_PER_TRUCK = 12.0

# --- HDT 物理参数 (使用健壮的参数) ---
LOADING_UNLOADING_TIME_HOURS = 0.5
SWAP_DURATION_HOURS = 0.25
HDT_BATTERY_CAPACITY_KWH = 350.0
HDT_MIN_SOC_KWH = HDT_BATTERY_CAPACITY_KWH * 0.20
HDT_EMPTY_WEIGHT_TON = 10.0
HDT_BASE_CONSUMPTION_KWH_PER_KM = 1.2
HDT_WEIGHT_CONSUMPTION_KWH_PER_KM_TON = 0.05

# --- EV & 能源站参数 ---
# MODIFIED: Added station-level BESS and stochastic generation parameters
STATION_BESS_CAPACITY_KWH = 1000.0   # 换电站自带储能容量
STATION_BESS_MAX_POWER_KW = 250.0    # 换电站储能最大充放电功率
STATION_BESS_EFFICIENCY = 0.93       # 储能充放电效率
STATION_MAX_GRID_POWER_KW = 2000     # 换电站从电网取电的最大功率
PV_PEAK_POWER_KW = 500               # 光伏峰值功率
PV_CLOUD_NOISE_LEVEL = 0.4           # 光伏波动噪声水平 (0-1)
EV_DEMAND_PEAK_KW = 200              # EV充电需求的峰值功率
EV_DEMAND_NOISE_LEVEL = 0.2          # EV充电需求的随机噪声水平

# --- 求解器与模型 ---
SOLVER_NAME = 'gurobi'
TIME_LIMIT_SECONDS = 600
BIG_M = 10000